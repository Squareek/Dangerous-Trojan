Hasło do pliku exe:  Ransomware

Instrukcje:
1. Wirusa zaprogramowałem jako exploit, więc przed uruchomieniem wyłącz neta.
2. Jest to ransomware, który wymaga wprowadzenia hasła po uruchomieniu (na dole)
3. Po upływie czasu usuwa się cały folder System32. 

Programy które wymaga wirus:
1. Net-Framwork 4.4 lub nowszy

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew

Programy użyte do realizacji:
1. Visual Studio 2019 (pisany w języku C#)
2. Adobe Photoshop 2021