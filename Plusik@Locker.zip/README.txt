hasło do pliku exe:      Brak


Instrukcje:
1. Wirus aby zadziałał potrzebuje połączenia z internetem
2. Wirus w ciągu 5 minut USUWA SNAPSHOT I KOPIE ZAPASOWE
3. Wirus to ransomware


Potrzebne programy:
1. Net-Framework

Systemy operacyjne na których działa:
1. Windows 7
2. Windows 10

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew

Programy użyte do realizacji:
1. Visual Studio 2019 