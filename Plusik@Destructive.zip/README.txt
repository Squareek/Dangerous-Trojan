Hasło do pliku exe: Destructive

Instrukcje:
1. Wirus jest typem trojana.
2. Wirus wymaga połączenia z internetem aby zadziałał.

Potrzebne programy:
1. Net-Framework 4.5
2. Internet

Systemy operacyjne na których działa:
1. Windows 7 - x64
2. Windows 8.1 - x64

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew\

Programy użyte do realizacji:
1. Visual Studio 2019
3. Visual Studio Code