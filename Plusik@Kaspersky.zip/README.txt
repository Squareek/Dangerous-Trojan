Hasło do pliku exe: Kaspersky

Instrukcje:
1. Wirus jest typem Win:TrojanRansom
2. Wszelkie opinie proszę kierować na discord'a:  Plusik#1871
3. Hasło do odszyfrowania: Kontakt na dc

Potrzebne programy:
1. Net-Framework 4.5

Systemy operacyjne na których działa:
1. Windows 7 - x64 oraz x32
2. Windows 8 - x64 oraz x32
3. Windows 8.1 - x64 oraz x32
4. Windows 10 - x64 oraz x32

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew\

Programy użyte do realizacji:
1. Visual Studio 2019
2. Adobe PhotoShop CC 2021
3. Visual Studio Code