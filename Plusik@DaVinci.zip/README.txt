Hasło do pliku exe: DaVinci

Instrukcje:
1. Wirus jest typem ransomware.
2. Został stworzony na cześć DaVinci.
3. Wirus wymaga połączenia z internetem aby zadziałał.

Potrzebne programy:
1. Net-Framework 4.5
2. Internet

Systemy operacyjne na których działa:
1. Windows 7 - x64
2. Windows 8.1 - x64
3. Windows 10 - x64 lub x32

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew\

Programy użyte do realizacji:
1. Visual Studio 2019
2. Office Word 2020
3. Visual Studio Code