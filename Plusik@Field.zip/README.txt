Hasło do pliku exe: Field

Instrukcje:
1. Wirus jest typem rasnomware.

Potrzebne programy:
1. Net-Framework 4.5

Systemy operacyjne na których działa:
1. Windows 7 - x64 oraz x32
2. Windows 8.1 - x64 oraz x64
3. Windows 10 - x64 (Home editon)

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew\

Programy użyte do realizacji:
1. Visual Studio 2019