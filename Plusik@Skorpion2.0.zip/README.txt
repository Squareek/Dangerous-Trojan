Hasło do pliku exe: Prywatne (kontakt discord)

Instrukcje:
1. Wirus jest typem ransomware i trojana
2. Jest on mojego autorstwa.
3. Wszelkie opinie proszę kierować na discord'a:  Plusik#1871

Potrzebne programy:
1. Net-Framework 4.5

Systemy operacyjne na których działa:
1. Windows 7 - x64 oraz x32
2. Windows 8 - x64 oraz x32
3. Windows 8.1 - x64 oraz x32
4. Windows 10 - x64 oraz x32

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew\

Programy użyte do realizacji:
1. Visual Studio 2019
2. Adobe PhotoShop CC 2021
3. Visual Studio Code