Hasło do pliku exe: Malware

Instrukcje:
1. Wirus to jeden wielki exploit, odłącznie od internetu obowiązkowe !!!
2. Wirus jest bardzo groźny, po jego uruchomieniu nie ma systemu.
3. W niektórych przypadkach może usunąć kopie zapasowe (snapshot)

Potrzebne programy:
1. Net-Framework 4.5 lub nowszy

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew

Programy użyte do realizacji:
1. Visual Studio 2019 
2. Visual Studio Code
3. Notepad
4. Wiersz Poleceń (Cmd)
