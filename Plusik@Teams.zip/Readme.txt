Hasło do pliku exe: Teams

Informacje:
1. Bardzo bardzo bardzo niebezpieczny wirus, po jego uruchomieniu dysk zostaje uszkodzony, a
po ponownym uruchomieniu systemu usuwa Windows 
2. Internet musi być włączony inaczej nie zadziała.
3. Testuj na wirtualnej maszynie, wirus nie przechodzi na główny system.
4. Autor nie ponosi odpowiedzialności, za szkody wyrządzone w wyniku uruchomienia
na prawdziwym komputerze.
5. Po uruchomieniu na głównym PC trzeba od razu zakupić nowy dysk ;)

Potrzebne programy:
1. Net Framework 4.4 lub nowszy
2. Pliki z folderu "Potrzebne"

Jak uruchomić:
1. Wszystkie pliki mają się znajdować na pulpicie, a nie w foldrze!
2. Uruchom program jako administator
3. Działa na Windows 7, 8.1 oraz 10


Autor: Plusik

Wykorzystane programy:
1. Visual Studio Code
2. Visual Studio 2019

Czas tworzenia programu: 3 dni, 6 godzin, 13 minut