Hasło do pliku exe:  Trojan

Ważne instrukcje.
1. Wirus działa na każdym systemie operacyjnym (Win 10, 8.1 , 7 itp).
2. Wirus usuwa pliki systemowe w folderze System32, po ponownym uruchomieniu system się nie włączy
4. Wirus powstał w celach edukacyjnych.
5. Uruchamianie na własną odpowiedzialność.


NAJWAŻNIEJSZE !!!!
- Testuj na wirtualnej maszynie


Potrzebne programy: 
1. Plusik@Tyeya.dll (w archiwum)

Autor: 
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew

Programy użyte do realizacji:
1. Visual Studio 2019
2. Archiwum (7z lub WinRar)
3. Visual Studio Code





