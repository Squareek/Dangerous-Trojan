Hasło do pliku exe: Invil

Instrukcje:
1. Wirus jest typem rasnomware.
2. Wirusa należy obowiązkowo uruchomiż w trybie zgodności z Win 7 !!!

Potrzebne programy:
1. Net-Framework 4.5

Systemy operacyjne na których działa:
1. Windows 7 - x64 oraz x32
2. Może działać na nowszych ale nie daje gwarancji !

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew\

Programy użyte do realizacji:
1. Visual Studio 2019
2. Adobe PhotoShop CC 2021