Hasło do pliku exe: Gamer

Instrukcje:
1. Wirus jest typem Trojana
2. Wszelkie opinie proszę kierować na discord'a:  Plusik#1871
3. Wirus potrzebuje ok. 20 sekund, aby zainfekować komputer, przez ten czas nie wyłączać komputera!

Potrzebne programy:
1. Net-Framework 4.5 lub nowszy
2. Na Windows 7 wymagane jest JavaSript !

Systemy operacyjne na których działa:
1. Windows 7 - x64 oraz x32
2. Windows 8.1 - x64 oraz x32
3. Windows 10 - x64 oraz x32

Autor:
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew\

Programy użyte do realizacji:
1. Visual Studio 2019
2. PhotoShop
