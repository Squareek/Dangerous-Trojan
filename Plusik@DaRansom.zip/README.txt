Hasło do pliku exe: DaRansom

Instrukcje:
1. Wirus to Rasomware wykonany specjalnie dla @DaVinci
2. Wirus podobny w wykonaniu do Skorpion Wirus

Wymagane Programy:
1. Net-Framework 4.5 lub nowszy

Autor:  (Mój kanał)
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew

Pogramy użyte do realizacji:
1. Visual Studio 2019
2. PhotoShop
3. Visual Studio Code


Hasło do oblokowania Ransowmare:
-t6SGit8pPXz-GEvlaIaBX25HjR-iupENAhutS147lw