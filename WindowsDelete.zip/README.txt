Hasło do pliku exe:  Trojan

Ważne instrukcje.
1. Wirus działa na każdym systemie operacyjnym (Win 10, 8.1 , 7 itp).
2. Wirus usuwa system, po uruchomieniu system jest do wyrzucenia.
3. Nie ma możliwości naprawy.
4. Wirus powstał w celach edukacyjnych.
5. Uruchamianie na własną odpowiedzialność.


NAJWAŻNIEJSZE !!!!
- Po włączeniu wirusa, uruchom ponownie komputer.


Potrzebne programy: 
1. Plik operacyjny.exe (w archiwum)

Autor: 
https://www.youtube.com/channel/UC9nQI7NiLdjKXUNmdk_2yew

Programy użyte do realizacji:
1. Visual Studio 2019
2. Archiwum (7z lub WinRar)
3. Wiersz Poleceń (cmd)





