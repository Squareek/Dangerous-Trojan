Hasło do pliku exe: Lunar

Instrukcje:
1. Wirus, nie jest zalecany dla osób z epilepsją! (Dużo Payloadów)
2. Wirus, potrzebuje połączenia z internetem aby zadziałał.
3. Jest to Fake Lunar Client. Po jego uruchomieniu, bios zostaje nadpisany, więc nie uruchamiaj
ponownie komputera
4. Po uruchomieniu wirusa, odczekaj ok. 30 sekund, na załadowanie się PayLoadów!

Potrzebne programy:
1. Net-Framework 4.5 lub nowszy

Systemy operacyjne na których działa:
1. Windows 10 - x64 oraz x32
2. Windows 8 - x64 oraz x32
3. Windows 7 - X64 oraz x43

Autor: Skorpion Plusik

Programy użyte do realizacji:
1. Visual Studio 2019
2. Visual Studio Code
3. Adobe PhotoShop CC 2021
